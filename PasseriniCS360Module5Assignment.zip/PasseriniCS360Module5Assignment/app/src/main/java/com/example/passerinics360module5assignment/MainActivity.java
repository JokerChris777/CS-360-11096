package com.example.passerinics360module5assignment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // STEP 1: Declare your UI variables at the class level
    private EditText nameText;
    private TextView textGreeting;
    private Button buttonSayHello;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // This is your original layout code for handling system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // STEP 2: Initialize the UI elements by linking them to their XML IDs
        nameText = findViewById(R.id.nameText);
        textGreeting = findViewById(R.id.textGreeting);
        buttonSayHello = findViewById(R.id.buttonSayHello);

        // STEP 3: Rubric requirement - Set initial button state to disabled
        buttonSayHello.setEnabled(false);

        // STEP 4: Rubric requirement - Add the TextChangedListener to nameText
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Intentionally left empty
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Trim the text to check for real text inputs instead of spaces
                String input = s.toString().trim();

                // Dynamically disable if there is no text; enable if text is entered
                if (input.isEmpty()) {
                    buttonSayHello.setEnabled(false);
                } else {
                    buttonSayHello.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Intentionally left empty
            }
        });
    }

    // STEP 5: Rubric requirement - Create the public greeting function
    public void SayHello(View view) {
        // Validation check: Ensure the EditText component is not null
        if (nameText != null && nameText.getText() != null) {
            String inputName = nameText.getText().toString().trim();

            // Validation check: If text contents are not null/empty, write the greeting
            if (!inputName.isEmpty()) {
                textGreeting.setText("Hello " + inputName);
            } else {
                return; // Gracefully return if empty string validation fails
            }
        } else {
            return; // Gracefully return if structural safety check fails
        }
    }
}