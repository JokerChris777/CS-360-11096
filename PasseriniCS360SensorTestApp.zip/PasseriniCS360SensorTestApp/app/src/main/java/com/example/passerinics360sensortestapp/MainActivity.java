package com.example.passerinics360sensortestapp;
{

private SensorManager sensorManager;
private Sensor lightSensor;
private TextView sensorTextView;

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    sensorTextView = findViewById(R.id.sensor_text);

    // Initialize the SensorManager
    sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

    // Select the Hardware Light Sensor
    if (sensorManager != null) {
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
    }

    // Safety check to see if the device/emulator supports it
    if (lightSensor == null) {
        sensorTextView.setText("Light sensor not available on this device!");
    }
}

@Override
protected void onResume() {
    super.onResume();
    // Register the listener when the app comes to the foreground
    if (lightSensor != null) {
        sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }
}

@Override
protected void onPause() {
    super.onPause();
    // Unregister to save battery when the app is in the background
    if (lightSensor != null) {
        sensorManager.unregisterListener(this);
    }
}

@Override
public void onSensorChanged(SensorEvent event) {
    // This method runs automatically when the sensor values change
    if (event.sensor.getType() == Sensor.TYPE_LIGHT) {
        float currentValue = event.values[0];
        sensorTextView.setText("Ambient Light: " + currentValue + " lx");
    }
}

@Override
public void onAccuracyChanged(Sensor sensor, int accuracy) {
    // Can be left empty for this assignment
}
}