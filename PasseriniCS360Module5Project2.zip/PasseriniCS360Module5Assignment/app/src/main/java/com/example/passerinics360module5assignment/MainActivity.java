package com.example.myapp; // Replace with your actual package name

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 1. Inflate your layout. If your login screen is your first screen,
        // set this to activity_login (or whatever you named your XML layout).
        setContentView(R.layout.activity_login);

        // 2. Check and prompt for SMS permission when the app launches
        checkSMSPermission();
    }

    // Method to check if the user has granted SMS permissions
    private void checkSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            // If permission is not granted, trigger the system permission request dialog
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            // Permission already granted
            Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle the user's response to the permission dialog
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // User clicked "Allow"
                Toast.makeText(this, "SMS Notification Permission Enabled", Toast.LENGTH_SHORT).show();
            } else {
                // User clicked "Deny" -> App must still function overall without notifications
                Toast.makeText(this, "Notifications Disabled. App will still function.", Toast.LENGTH_LONG).show();
            }
        }
    }
}